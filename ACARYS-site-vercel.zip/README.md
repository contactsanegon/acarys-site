# ACARYS — Site vitrine prêt pour Vercel

## Contenu
- `index.html` : page d'accueil responsive
- `styles.css` : design noir et or
- `script.js` : menu mobile et formulaire `mailto`
- `mentions-legales.html` et `confidentialite.html` : pages modèles à compléter
- `assets/favicon.svg` : favicon

## Prévisualisation locale
Ouvrez `index.html` dans un navigateur. Pour une prévisualisation plus fidèle, vous pouvez utiliser l'extension Live Server de VS Code.

## Déploiement sur Vercel
1. Décompressez le ZIP.
2. Créez un dépôt GitHub et ajoutez les fichiers à la racine du dépôt.
3. Connectez-vous à https://vercel.com/ et choisissez **Add New → Project**.
4. Importez le dépôt GitHub.
5. Pour ce site statique, laissez le framework sur **Other** et ne renseignez ni commande de build ni dossier de sortie.
6. Cliquez sur **Deploy**.
7. Dans les réglages du projet, ajoutez votre domaine personnalisé lorsque vous en disposerez et suivez les instructions DNS affichées par Vercel.

## À vérifier avant publication
- Confirmer que le nom ACARYS peut être utilisé et que le nom de domaine est disponible.
- Confirmer la raison sociale qui exploitera le site, l'adresse et les informations réglementaires.
- Compléter les mentions légales et la politique de confidentialité avec les informations exactes.
- Vérifier les coordonnées affichées et l'adresse e-mail de réception.
- Le formulaire ouvre le logiciel de messagerie du visiteur : il ne transmet pas directement les demandes à un serveur. Pour un formulaire en ligne réellement intégré, il faudra ajouter un service de formulaire ou une fonction serveur.
- Le site n'affirme pas que l'agence ACARYS possède une autorisation ou un agrément spécifique. Ajoutez les références exactes uniquement après vérification.
- L'expérience de plus de 30 ans mentionnée sur le site doit être validée pour la marque et l'entité qui l'exploitera.

## Personnalisation
Recherchez `contactsanegon@gmail.com` dans `index.html` et `script.js` si vous souhaitez utiliser une adresse distincte pour ACARYS.
