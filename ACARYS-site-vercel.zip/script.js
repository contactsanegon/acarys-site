const menuToggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('.main-nav');
if (menuToggle && nav) {
  menuToggle.addEventListener('click', () => {
    const isOpen = nav.classList.toggle('open');
    menuToggle.setAttribute('aria-expanded', String(isOpen));
    menuToggle.setAttribute('aria-label', isOpen ? 'Fermer le menu' : 'Ouvrir le menu');
    menuToggle.textContent = isOpen ? '×' : '☰';
  });
  nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
    nav.classList.remove('open');
    menuToggle.setAttribute('aria-expanded', 'false');
    menuToggle.textContent = '☰';
  }));
}
document.getElementById('year').textContent = new Date().getFullYear();

const form = document.getElementById('contact-form');
form.addEventListener('submit', (event) => {
  event.preventDefault();
  const data = new FormData(form);
  const subject = `Demande de contact ACARYS — ${data.get('subject')}`;
  const body = [
    `Nom : ${data.get('name')}`,
    `E-mail : ${data.get('email')}`,
    `Téléphone : ${data.get('phone') || 'Non renseigné'}`,
    `Objet : ${data.get('subject')}`,
    '',
    'Message :',
    data.get('message')
  ].join('\n');
  const mailto = `mailto:contactsanegon@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  document.getElementById('form-status').textContent = 'Votre logiciel de messagerie va s’ouvrir avec votre message prérempli.';
  window.location.href = mailto;
});
